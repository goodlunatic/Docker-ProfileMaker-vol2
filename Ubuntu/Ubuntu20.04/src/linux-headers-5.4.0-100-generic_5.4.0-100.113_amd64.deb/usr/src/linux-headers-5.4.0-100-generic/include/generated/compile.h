/* This file is auto generated, version 113-Ubuntu */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#113-Ubuntu SMP Thu Feb 3 18:43:29 UTC 2022"
#define LINUX_COMPILE_BY "buildd"
#define LINUX_COMPILE_HOST "lcy02-amd64-002"
#define LINUX_COMPILER "gcc version 9.3.0 (Ubuntu 9.3.0-17ubuntu1~20.04)"
