#define UTS_RELEASE "4.13.0-36-generic"
#define UTS_UBUNTU_RELEASE_ABI 36
