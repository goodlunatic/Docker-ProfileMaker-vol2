/*  This is a dummy to create a tiny executable
    we will use in make check on debuglink
    Compiled by
        cc -g dummyexecutable.c -o dummyexecutable
    On Ubuntu 18.04 10 November 2019
*/
#include <stdio.h>

int myfunc(unsigned x)
{
    int z = x +3;
    return z;
}

int main(int argc, char **argv)
{
    int zed = 0;

    zed = myfunc(zed +2);
    return zed;
}
